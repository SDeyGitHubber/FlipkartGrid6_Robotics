# FullKart > 2024-09-21 6:27am
https://universe.roboflow.com/bjbj/fullkart

Provided by a Roboflow user
License: CC BY 4.0

